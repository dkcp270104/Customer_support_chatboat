from sqlalchemy.orm import Session
from . import models

def get_top_sold_products(db: Session, limit: int = 5):
    return db.query(models.Product).order_by(models.Product.sold.desc()).limit(limit).all()

def get_order_status(db: Session, order_id: int):
    return db.query(models.Order).filter(models.Order.id == order_id).first()

def get_stock_by_name(db: Session, product_name: str):
    return db.query(models.Product).filter(models.Product.name.ilike(f"%{product_name}%")).all()

def save_chat(db: Session, conv_id: str, user_msg: str, bot_msg: str):
    chat = models.Chat(conversation_id=conv_id, user_message=user_msg, bot_response=bot_msg)
    db.add(chat)
    db.commit()
