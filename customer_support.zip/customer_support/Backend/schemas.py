from pydantic import BaseModel

class ProductSchema(BaseModel):
    id: int
    name: str
    category: str
    quantity: int
    sold: int
    class Config:
        orm_mode = True

class OrderSchema(BaseModel):
    id: int
    status: str
    class Config:
        orm_mode = True

class ChatRequest(BaseModel):
    message: str
    conversation_id: str | None = None

class ChatResponse(BaseModel):
    response: str
    conversation_id: str
