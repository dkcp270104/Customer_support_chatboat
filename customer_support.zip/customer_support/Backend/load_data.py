import csv
from . import models, database

def load_products():
    db = database.SessionLocal()
    with open("backend/sample_data.csv", "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            db_product = models.Product(
                id=int(row['id']),
                name=row['name'],
                category=row['category'],
                quantity=int(row['quantity']),
                sold=int(row['sold'])
            )
            db.add(db_product)
        db.commit()
        db.close()

if __name__ == "__main__":
    models.Base.metadata.create_all(bind=database.engine)
    load_products()
