from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from . import database, crud, schemas
from .groq_client import query_llm

app = FastAPI()

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/top-products", response_model=list[schemas.ProductSchema])
def top_products(db: Session = Depends(get_db)):
    return crud.get_top_sold_products(db)

@app.get("/order-status/{order_id}", response_model=schemas.OrderSchema)
def order_status(order_id: int, db: Session = Depends(get_db)):
    order = crud.get_order_status(db, order_id)
    if not order:
        return {"id": order_id, "status": "Not found"}
    return order

@app.get("/stock/{product_name}", response_model=list[schemas.ProductSchema])
def product_stock(product_name: str, db: Session = Depends(get_db)):
    return crud.get_stock_by_name(db, product_name)

@app.post("/api/chat", response_model=schemas.ChatResponse)
def chat_with_bot(payload: schemas.ChatRequest, db: Session = Depends(get_db)):
    response = query_llm(payload.message)
    conv_id = payload.conversation_id or "conv_001"
    crud.save_chat(db, conv_id, payload.message, response)
    return {"response": response, "conversation_id": conv_id}
